function initModel() {
	var sUrl = "/sap/opu/odata/sap/ZFAR_JPMC_CCLAIM_SRV/";
	var oModel = new sap.ui.model.odata.ODataModel(sUrl, true);
	sap.ui.getCore().setModel(oModel);
}