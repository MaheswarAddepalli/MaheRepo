sap.ui.define([
	"WCMNS/JPMC/test/unit/controller/Home.controller"
], function () {
	"use strict";
});