/* global QUnit*/

sap.ui.define([
	"sap/ui/test/Opa5",
	"WCMNS/JPMC/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"WCMNS/JPMC/test/integration/pages/Home",
	"WCMNS/JPMC/test/integration/navigationJourney"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "WCMNS.JPMC.view.",
		autoWait: true
	});
});