sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/format/DateFormat",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/odata/v2/ODataModel",
	"sap/m/MessageBox",
	"sap/m/MessageToast"

], function (Controller, DateFormat, Filter, FilterOperator, JSONModel, ODataModel,MessageBox,MessageToast) {
	"use strict";

	return Controller.extend("WCMNS.JPMC.controller.Home", {
		onInit: function () {
			//Getting default model
			this.ODModel = this.getOwnerComponent().getModel();
		},
		onShowFilesBtn: function (oEvent) {
			debugger;
			var test = this.getView();
			var Filedate1 = this.getView().byId("idDtF").getDateValue();
			var Filedate2 = this.getView().byId("idDtF").getSecondDateValue();
			var budate1 = this.getView().byId("idDtP").getDateValue();
			var budate2 = this.getView().byId("idDtP").getSecondDateValue();
			var bIsChecked = this.getView().byId("idChB").getSelected();
			var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
				pattern: "yyyy-MM-dd"
	//			,UTC:true
			});
			Filedate1 = oDateFormat.format(Filedate1);
			Filedate2 = oDateFormat.format(Filedate2);
			if (budate1 !== null){
			budate1 = oDateFormat.format(budate1);
			}
			if (budate2 !== null){
			budate2 = oDateFormat.format(budate2);
			}
            var cSel = this.getView().byId("idChB").getSelected();
            var aFitlers = [];
            if (cSel === false){
			aFitlers = [
				new Filter('Filedate', FilterOperator.EQ, Filedate1),
				new Filter('ToFdate', FilterOperator.EQ, Filedate2),
				new Filter('Budat', FilterOperator.EQ, budate1),
				new Filter('ToBudat', FilterOperator.EQ, budate2)
			];
            }else{
            debugger;	
            	this.getView().byId("idDtP").setDateValue();
            budate1  = null;
            budate2  = null;
             aFitlers = [
				new Filter('Filedate', FilterOperator.EQ, Filedate1),
				new Filter('ToFdate', FilterOperator.EQ, Filedate2)
			];	
            }
            
			var oModel = this.getOwnerComponent().getModel();
			var oJsonModel = new sap.ui.model.json.JSONModel();
			
			if((cSel === false && budate1 !== null) || (cSel === true && budate1 === null)){
			this.getOwnerComponent().setModel(oJsonModel, "resultModel");
			oModel.read("/BCHdrSet", {
				filters: aFitlers,
				success: function (data) {
					oJsonModel.setData(data);
					this.getOwnerComponent().getRouter().navTo("Transactionroot");
				}.bind(this),
				
				error: function (err) {
					
				}

			});  // Read
			}else{
				MessageToast.show("Please select Processed date/change selection");
			}
			
		},
		onExcludeCBox: function (oEvent) {
		//Enable Processed Date input when unchecked.
						var eCheckB = oEvent.getSource();
						var pDate = this.byId("idDtP");
						if (eCheckB.getSelected() === true) {
							pDate.setEnabled(false);
							this.getView().byId("idDtP").setDateValue();
						} else {
							pDate.setEnabled(true);
						}
						 this.echkb = eCheckB;
		}
	});
});
