sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"WCMNS/JPMC/model/formatter",
	"sap/ui/model/odata/v2/ODataModel",
	"sap/m/MessageBox",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (Controller,formatter,ODataModel,MessageBox,Filter,FilterOperator) {
	"use strict";

	return Controller.extend("WCMNS.JPMC.controller.Transactions", {
	    formatter: formatter,	
		onInit: function () { },
		onPatternMatched: function() { }, 
		onTradet: function (oEvent) {
//Details Set
			var cSel = oEvent.getSource().getText();
		    var cDesc = 'Test';
            var aFitlers = [];
    		aFitlers = [
				new Filter('Runid', FilterOperator.EQ, cSel),
				new Filter('ZbcDesc', FilterOperator.EQ, cDesc)
			];
    		var oModelt		= this.getOwnerComponent().getModel();
			var oJsonModelt = new sap.ui.model.json.JSONModel();
			var oJsonTobe   = new sap.ui.model.json.JSONModel();
			var oJsonNoAc   = new sap.ui.model.json.JSONModel();
			var tobe		= [];
			var noac		= [];
			var tobeJson	= {};
			var noacJson	= {};
			this.getOwnerComponent().setModel(oJsonModelt, "resultModel2");
			this.getOwnerComponent().setModel(oJsonTobe, "tobeModel");
			this.getOwnerComponent().setModel(oJsonNoAc, "noacModel");
		 
		 //oModelt.read("/BCHdrSet('0000000052')/BCDtlItem", {  
		 oModelt.read("/BCHdrSet('" + cSel + "')/BCDtlItem", {  
				filters: aFitlers,
				success: function (data) {
					
					for(var i=0;i<data.results.length;i++){
						if(data.results[i].RemrkDisp === "TOBE"){
							tobe.push(data.results[i]);  // Assigning to array
						}
						if(data.results[i].RemrkDisp === "NOAC"){
							noac.push(data.results[i]);
						}
					}
					
					oJsonModelt.setData(data);
					tobeJson.results = tobe; // Assigning to JSON object
					noacJson.results = noac;
					oJsonTobe.setData(tobeJson); // Assigning to Model
					oJsonNoAc.setData(noacJson);
					this.getOwnerComponent().getRouter().navTo("Tradetroot");

				}.bind(this),
				error: function (err) {
					
				}
			});  // Read
		},// tradet
		onBack: function () {
			this.getOwnerComponent().getRouter().navTo("Homeroot");
		}
	});
});


