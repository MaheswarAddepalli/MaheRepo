sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/format/DateFormat",
	"sap/ui/model/Filter",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/odata/v2/ODataModel",
	"WCMNS/JPMC/model/formatter",
	"sap/m/Dialog",
	"sap/m/ButtonType",
	"sap/m/Button",
	"sap/m/MessageToast",
	"sap/ui/core/util/Export",
	"sap/ui/core/util/ExportTypeCSV",
	"sap/ui/model/FilterOperator",
	"sap/m/SearchField",
	"sap/ui/model/type/String",
	"sap/m/ColumnListItem",
	"sap/m/Label",
	"sap/ui/table/Table",
	"sap/m/MessageBox",
//***	

	"sap/ui/comp/library",
	"sap/ui/model/type/String",
	"sap/m/Token"
//***	

], function (Controller, DateFormat, Filter, JSONModel, ODataModel, formatter, Dialog, ButtonType, Button, MessageToast, Export,
	ExportTypeCSV, FilterOperator, SearchField, typeString, ColumnListItem, Label, Table, MessageBox,
	library,String,Token) {
	"use strict";
	var newToBeGlVal = [];
	var oJsonRmModel = new sap.ui.model.json.JSONModel();
	var tobeupdatedar = [];
	var docSaved = " ";
	var docNotSaved = " ";
	var docModified = " ";
	var docNotModified = " ";
	
	return Controller.extend("WCMNS.JPMC.controller.Tradet", {
		formatter: formatter,
		onInit: function () {
			this.getView().byId("idDtPdt").setDateValue(new Date());
			var sBudat = this.getView().byId("idDtPdt").getValue();
	        this._oMultiInput = this.getView().byId("multiInput");
	        this.oColModel = new JSONModel();
	        this.oProductsModel = new JSONModel();
			var oJModel = new JSONModel("model/data.json");
			this.getView().setModel(oJModel);
				var oDateFormatT = sap.ui.core.format.DateFormat.getDateTimeInstance({
				pattern: "yyyy-MM-dd"});
		},
		onSave: function (oEvent) {
			this.oErrModel = this.getOwnerComponent().getModel();
			var sBudat = this.getView().byId("idDtPdt").getValue();
			var sdate = new Date();
			var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
				pattern: "yyyy-MM-ddThh:mm:ss"
			});
			var postingDt = oDateFormat.format(sdate);
			var selBtn = oEvent.getSource().getId();
			var action = ""; //{};
			var jSonObjGlS = {};
			var newToBeGlValS = [];
			var finalAr = [];
			var sRunid = "";
			if (selBtn == "__xmlview3--tSave1") {
				action = "S";
			}
			if (selBtn == "__xmlview3--tSimu1") {
				action = "V";
			}
			if (selBtn == "__xmlview3--tPost1") {
				action = "P";
			}
			//save
			debugger;
			if (action == "S") {
				
				for (var i = 0; i < tobeupdatedar.length; i++) {
					sRunid = tobeupdatedar[0].actRunid;
					jSonObjGlS = {
				
						Runid: tobeupdatedar[i].actRunid,
						LineNumber: tobeupdatedar[i].actLineNumber,
						LineNo: tobeupdatedar[i].actLineNo,
						ZbcValueDate: tobeupdatedar[i].actZbcValueDate,
						Wrbtr: tobeupdatedar[i].actWrbtr,
						Waers: tobeupdatedar[i].actWaers,
						ZbcDesc: tobeupdatedar[i].actZbcDesc,
						ZbcCustRef: tobeupdatedar[i].actZbcCustRef,
						ZbcBankRef: tobeupdatedar[i].actZbcBankRef,
						ZbcRecType: tobeupdatedar[i].actZbcRecType,
						ZbcTranType: tobeupdatedar[i].actZbcTranType,
						ZbcRemrk01: tobeupdatedar[i].actZbcRemrk01,
						ZbcDocgrp: tobeupdatedar[i].actZbcDocgrp,
						Saknr: tobeupdatedar[i].actSaknr,
						Geber: tobeupdatedar[i].actGeber,
						Belnr: tobeupdatedar[i].actBelnr,
						Buzei: tobeupdatedar[i].actBuzei,
						Zupdby: tobeupdatedar[i].actZupdby,
						ReadOnly: tobeupdatedar[i].actReadOnly,
						AutoDtr: tobeupdatedar[i].actAutoDtr,
						RemrkDisp: tobeupdatedar[i].actRemrkDisp,
						ItemStatus: tobeupdatedar[i].actItemStatus,
						Msg: tobeupdatedar[i].actMsg,
						Status: tobeupdatedar[i].actStatus
					}
					newToBeGlValS.push(jSonObjGlS); //json
				}
				finalAr = newToBeGlValS; //Final tab to save simulate and Post
			}
			//simulate
			if (action == "V" || action == "P") {
			
			var oModelerr = this.getOwnerComponent().getModel();
			var errJModel = new sap.ui.model.json.JSONModel();
			this.getOwnerComponent().setModel(errJModel, "errModel");
			
			
				
				// var oModelSi = this.getOwnerComponent().getModel("resultModel2");
				var oModelSi = this.getOwnerComponent().getModel("tobeModel");
				var jSonObjGlSI = {};
				var newToBeGlValSi = [];
				debugger;
				for (var i = 0; i < oModelSi.oData.results.length; i++) {
					sRunid = oModelSi.oData.results[0].Runid;
					jSonObjGlSI = {
			
						Runid: oModelSi.oData.results[i].Runid,
						LineNumber: oModelSi.oData.results[i].LineNumber,
						LineNo: oModelSi.oData.results[i].LineNo,
						ZbcValueDate: oModelSi.oData.results[i].ZbcValueDate,
						Wrbtr: oModelSi.oData.results[i].Wrbtr,
						Waers: oModelSi.oData.results[i].Waers,
						ZbcDesc: oModelSi.oData.results[i].ZbcDesc,
						ZbcCustRef: oModelSi.oData.results[i].ZbcCustRef,
						ZbcBankRef: oModelSi.oData.results[i].ZbcBankRef,
						ZbcRecType: oModelSi.oData.results[i].ZbcRecType,
						ZbcTranType: oModelSi.oData.results[i].ZbcTranType,
						ZbcRemrk01: oModelSi.oData.results[i].ZbcRemrk01,
						ZbcDocgrp: oModelSi.oData.results[i].ZbcDocgrp,
						Saknr: oModelSi.oData.results[i].Saknr,
						Geber: oModelSi.oData.results[i].Geber,
						Belnr: oModelSi.oData.results[i].Belnr,
						Buzei: oModelSi.oData.results[i].Buzei,
						Zupdby: oModelSi.oData.results[i].Zupdby,
						ReadOnly: oModelSi.oData.results[i].ReadOnly,
						AutoDtr: oModelSi.oData.results[i].AutoDtr,
						RemrkDisp: oModelSi.oData.results[i].RemrkDisp,
						ItemStatus: oModelSi.oData.results[i].ItemStatus,
						Msg: oModelSi.oData.results[i].Msg,
						Status: oModelSi.oData.results[i].Status,
					}
					newToBeGlValSi.push(jSonObjGlSI); //json
				}
				finalAr = newToBeGlValSi; //Final tab to save simulate and Post
			}
            //Payload 
	    	var payload = {
					"Runid": sRunid,//"0000000052", // dummy header
					"Filedate": "2020-01-13T16:03:39", // dummy header
					"ZbcRecCnt": "000018", // dummy header
					"Bukrs": "",// dummy header
					"Gjahr": "0000",// dummy header
					"Budat": null,// dummy header
					"Totcr": "0.000",// dummy header
					"Totdr": "1494510.150",// dummy header
					"Zcreby": "",// dummy header
					"Zcredate": null,// dummy header
					"ActFlg": action, //"S",// dummy header
					"PostingDate":postingDt,// "2020-01-13T16:03:39", //sBudat,//
					"Msg": "",// dummy header
					"ToFdate": null,// dummy header
					"ToBudat": null,// dummy header
					"BCDtlItem": finalAr// dummy header
				} //payload
			//Data retrival
			debugger;
			var oModelU = this.getOwnerComponent().getModel();
			
            var aErr = [];
			// /sap/opu/odata/sap/ZFAR_JPMC_CCLAIM_SRV/BCHdrSet		
			oModelU.create("/BCHdrSet", payload, {

				success: function (oRes) {
					debugger;
					console.log("Inside Success");
					if(oRes.Msg === "Data was saved")
					{ 
						MessageToast.show("Data Saved");
						
					}
					
					
					docSaved = "X";
					debugger;
					var err = [];
					for(var i = 0;i<oRes.BCDtlItem.results.length;i++){
					err.push(oRes.BCDtlItem.results[0].Msg);
					if(oRes.BCDtlItem.results[0].Belnr !== ""){
					MessageToast.show(oRes.BCDtlItem.results[0].Belnr + "Created");
					}
					};
					debugger;
					
				},//Sucess
				error: function (err) {
					debugger;
					docNotSaved = "X"
					console.log("Inside error");
					// MessageToast.show("Error in Network/Save/Simulation/Posting,Pls.. check error log");
					var errorObj1 = JSON.parse(err.responseText);
					console.log("sample",errorObj1);
					for(var i=0;i<errorObj1.error.innererror.errordetails.length;i++){
						// if(errorObj1.error.innererror.errordetails[i].severity === "error"){
						aErr.push(errorObj1.error.innererror.errordetails[i]);
						// console.log("sample2",aErr[0]);
						// }
						
						}
					debugger;
						var errJO = {};
				        errJO.results = aErr; 
				        errJModel.setData(errJO); 
				        console.log("sample3",errJO);
                        MessageToast.show("Please check log");
		
		    debugger;
		
			
			
			
// data: ls_return_msg TYPE BAPIRET2.

// data: lt_return_msg TYPE BAPIRET2_T.

// data: lo_message TYPE REF TO /IWBEP/IF_MESSAGE_CONTAINER.

// data: lx_bus_ex TYPE REF TO /IWBEP/CX_MGW_BUSI_EXCEPTION.

// LT_RETURN_MSG = et_msg.

// LO_MESSAGE = MO_CONTEXT->GET_MESSAGE_CONTAINER( ).

// LO_MESSAGE->ADD_MESSAGES_FROM_BAPI( IT_BAPI_MESSAGES = LT_RETURN_MSG ).

// create OBJECT lx_bus_ex

// exporting message_container = LO_MESSAGE.

// raise EXCEPTION lx_bus_ex.
// /IWBEP/CX_MGW_BUSI_EXCEPTION
// /IWBEP/CX_MGW_TECH_EXCEPTION

				} //error
				
			}); //create
			
			debugger;

//eror handling			
			// var errJO = {};
			// 	errJO.results = aErr; 
			// 	errJModel.setData(errJO); 

		}, //save
		//GlF4 Help 
		onGlF4Help: function (oEvent) {
			debugger;
			this.inGlId = oEvent.getSource().getId();
			this.rowId = oEvent.getSource().oParent.getId();
			this.rowIndex = oEvent.getSource().oParent.getIndex();
			this.oldVlaue = oEvent.getSource().getValue();
			
	//** getting F4 values
	debugger;
	        var aGlFitlers = [];
			aGlFitlers = [
				new Filter('Ktopl', FilterOperator.EQ, "WCMC")
			];
			var oGlF4Model = this.getOwnerComponent().getModel();
			var oJsonGlModel = new sap.ui.model.json.JSONModel();
			var jGLO = {};
			var glAr = [];
			this.getOwnerComponent().setModel(oJsonGlModel, "resultGlModel");
			oGlF4Model.read("/BCGlAccSet", {
				 //oJsonModel.setProperty("/TimeEntrySet",oData.results); setting odat directky to entityset 
				 //Use the method setSizeLimit in your model.


				filters: aGlFitlers,
				success: function (data) {
					debugger;
					for (var i = 0; i < data.results.length; i++) {
						glAr.push(data.results[i]);
					}
					jGLO.results = glAr; 
					oJsonGlModel.setData(jGLO); 
				}
				});

	//**
	
			
			
			if (!this.dialog) {
				this.dialog = sap.ui.xmlfragment(this.getView().getId(), "WCMNS.JPMC.view.fragment.glValueHelp", this);
				this.getView().addDependent(this.dialog);
			}
			this.dialog.open();
		},
		onGlSelF4Help: function (oEvent) {
			debugger;
			docModified = "";
			docSaved = "";
			var selGlSaknr = "";
			selGlSaknr = oEvent.getSource().getSelectedItem().mAggregations.cells[0].mProperties.text;
			
			var actRunid = this.getOwnerComponent().getModel("tobeModel").oData.results[this.rowIndex].Runid;
			var actLineNumber = this.getOwnerComponent().getModel("tobeModel").oData.results[this.rowIndex].LineNumber;
			var actLineNo = this.getOwnerComponent().getModel("tobeModel").oData.results[this.rowIndex].LineNo;
			var actZbcValueDate = this.getOwnerComponent().getModel("tobeModel").oData.results[this.rowIndex].ZbcValueDate;
			var actWrbtr = this.getOwnerComponent().getModel("tobeModel").oData.results[this.rowIndex].Wrbtr;
			var actWaers = this.getOwnerComponent().getModel("tobeModel").oData.results[this.rowIndex].Waers;
			var actZbcDesc = this.getOwnerComponent().getModel("tobeModel").oData.results[this.rowIndex].ZbcDesc;
			var actZbcCustRef = this.getOwnerComponent().getModel("tobeModel").oData.results[this.rowIndex].ZbcCustRef;
			var actZbcBankRef = this.getOwnerComponent().getModel("tobeModel").oData.results[this.rowIndex].ZbcBankRef;
			var actZbcRecType = this.getOwnerComponent().getModel("tobeModel").oData.results[this.rowIndex].ZbcRecType;
			var actZbcTranType = this.getOwnerComponent().getModel("tobeModel").oData.results[this.rowIndex].ZbcTranType;
			var actZbcRemrk01 = this.getOwnerComponent().getModel("tobeModel").oData.results[this.rowIndex].ZbcRemrk01;
			var actZbcDocgrp = this.getOwnerComponent().getModel("tobeModel").oData.results[this.rowIndex].ZbcDocgrp;
			var actSaknr = this.getOwnerComponent().getModel("tobeModel").oData.results[this.rowIndex].Saknr;
			var actGeber = this.getOwnerComponent().getModel("tobeModel").oData.results[this.rowIndex].Geber;
			var actBelnr = this.getOwnerComponent().getModel("tobeModel").oData.results[this.rowIndex].Belnr;
			var actBuzei = this.getOwnerComponent().getModel("tobeModel").oData.results[this.rowIndex].Buzei;
			var actZupdby = this.getOwnerComponent().getModel("tobeModel").oData.results[this.rowIndex].Zupdby;
			var actReadOnly = this.getOwnerComponent().getModel("tobeModel").oData.results[this.rowIndex].ReadOnly;
			var actAutoDtr = this.getOwnerComponent().getModel("tobeModel").oData.results[this.rowIndex].AutoDtr;
			var actRemrkDisp = this.getOwnerComponent().getModel("tobeModel").oData.results[this.rowIndex].RemrkDisp;
			var actItemStatus = this.getOwnerComponent().getModel("tobeModel").oData.results[this.rowIndex].ItemStatus;
			var actMsg = this.getOwnerComponent().getModel("tobeModel").oData.results[this.rowIndex].Msg;
			var actStatus = this.getOwnerComponent().getModel("tobeModel").oData.results[this.rowIndex].Status;

			var glval = this.oldVlaue; //PREVIOUS SEELCTION
			var recFound = "";
			if (actSaknr !== selGlSaknr) {
				actSaknr = selGlSaknr;
				if (tobeupdatedar.length === 0) {
			
					tobeupdatedar.push({
						actRunid,
						actLineNumber,
						actLineNo,
						actZbcValueDate,
						actWrbtr,
						actWaers,
						actZbcDesc,
						actZbcDesc,
						actZbcCustRef,
						actZbcBankRef,
						actZbcRecType,
						actZbcTranType,
						actZbcRemrk01,
						actZbcDocgrp,
						actSaknr,
						actGeber,
						actBelnr,
						actBuzei,
						actZupdby,
						actReadOnly,
						actAutoDtr,
						actRemrkDisp,
						actItemStatus,
						actMsg,
						actStatus
					});

					docModified = "X";
				} else {

					for (var i = 0; i < tobeupdatedar.length; i++) {
						if (tobeupdatedar[i].actLineNumber === actLineNumber) {
							// tobeupdatedar[i].actSaknr = selGlSaknr;
							tobeupdatedar[i].actSaknr = actSaknr;
							recFound = true;
							docModified = "X";

						}
					}

					if (!recFound) {
					
					tobeupdatedar.push({
							actRunid,
							actLineNumber,
							actLineNo,
							actZbcValueDate,
							actWrbtr,
							actWaers,
							actZbcDesc,
							actZbcDesc,
							actZbcCustRef,
							actZbcBankRef,
							actZbcRecType,
							actZbcTranType,
							actZbcRemrk01,
							actZbcDocgrp,
							actSaknr,
							actGeber,
							actBelnr,
							actBuzei,
							actZupdby,
							actReadOnly,
							actAutoDtr,
							actRemrkDisp,
							actItemStatus,
							actMsg,
							actStatus
						});

						docModified = "X";

					}
				}

			}


			this.getView().byId(this.inGlId).setValue(selGlSaknr);
			oEvent.getSource().getParent().close();
			this.dialog.close();

		}, //glhelp
		onGlF4HelpClose: function (oEvent) {
			debugger;
			this.dialog.close();
		},
		onGlF4Search: function (oEvent) {
			debugger;
			
			var sValue = oEvent.getParameters("newValue");
			var sVal = sValue.newValue;
			var oFilter1 = new Filter("Saknr", sap.ui.model.FilterOperator.Contains, sVal);
			var aFilters = [];
			aFilters.push(oFilter1);
			var oBinding = this.getView().byId("tableGlF").getBinding("items");
			oBinding.filter(aFilters);
			
		},
		onGlChange: function (oEvent) {
			debugger;
			var cGlChId = oEvent.getSource().getId();
			var cGlChrowId = oEvent.getSource().oParent.getId();
			var cGlChIndex = oEvent.getSource().oParent.getIndex();
			var cGlChVal = oEvent.getSource().getValue();
			var cval = oEvent.getSource().oParent.mAggregations.cells[0].mProperties.text;
			debugger;
			docModified = "";
			docSaved = "";
			
			
			var actRunid = this.getOwnerComponent().getModel("tobeModel").oData.results[cGlChIndex].Runid;
			var actLineNumber = this.getOwnerComponent().getModel("tobeModel").oData.results[cGlChIndex].LineNumber;
			var actLineNo = this.getOwnerComponent().getModel("tobeModel").oData.results[cGlChIndex].LineNo;
			var actZbcValueDate = this.getOwnerComponent().getModel("tobeModel").oData.results[cGlChIndex].ZbcValueDate;
			var actWrbtr = this.getOwnerComponent().getModel("tobeModel").oData.results[cGlChIndex].Wrbtr;
			var actWaers = this.getOwnerComponent().getModel("tobeModel").oData.results[cGlChIndex].Waers;
			var actZbcDesc = this.getOwnerComponent().getModel("tobeModel").oData.results[cGlChIndex].ZbcDesc;
			var actZbcCustRef = this.getOwnerComponent().getModel("tobeModel").oData.results[cGlChIndex].ZbcCustRef;
			var actZbcBankRef = this.getOwnerComponent().getModel("tobeModel").oData.results[cGlChIndex].ZbcBankRef;
			var actZbcRecType = this.getOwnerComponent().getModel("tobeModel").oData.results[cGlChIndex].ZbcRecType;
			var actZbcTranType = this.getOwnerComponent().getModel("tobeModel").oData.results[cGlChIndex].ZbcTranType;
			var actZbcRemrk01 = this.getOwnerComponent().getModel("tobeModel").oData.results[cGlChIndex].ZbcRemrk01;
			var actZbcDocgrp = this.getOwnerComponent().getModel("tobeModel").oData.results[cGlChIndex].ZbcDocgrp;
			var actSaknr = this.getOwnerComponent().getModel("tobeModel").oData.results[cGlChIndex].Saknr;
			var actGeber = this.getOwnerComponent().getModel("tobeModel").oData.results[cGlChIndex].Geber;
			var actBelnr = this.getOwnerComponent().getModel("tobeModel").oData.results[cGlChIndex].Belnr;
			var actBuzei = this.getOwnerComponent().getModel("tobeModel").oData.results[cGlChIndex].Buzei;
			var actZupdby = this.getOwnerComponent().getModel("tobeModel").oData.results[cGlChIndex].Zupdby;
			var actReadOnly = this.getOwnerComponent().getModel("tobeModel").oData.results[cGlChIndex].ReadOnly;
			var actAutoDtr = this.getOwnerComponent().getModel("tobeModel").oData.results[cGlChIndex].AutoDtr;
			var actRemrkDisp = this.getOwnerComponent().getModel("tobeModel").oData.results[cGlChIndex].RemrkDisp;
			var actItemStatus = this.getOwnerComponent().getModel("tobeModel").oData.results[cGlChIndex].ItemStatus;
			var actMsg = this.getOwnerComponent().getModel("tobeModel").oData.results[cGlChIndex].Msg;
			var actStatus = this.getOwnerComponent().getModel("tobeModel").oData.results[cGlChIndex].Status;

			var glval = this.oldVlaue; //PREVIOUS SEELCTION
			// var selGlSaknr = oEvent.getParameter("listItem").getBindingContext().getProperty("Saknr"); // CURRENT SELECTION
			var recFound = "";
			// if (actSaknr !== cGlChVal) {
				actSaknr = cGlChVal;
				if (tobeupdatedar.length === 0) {
					// tobeupdatedar.push({actRunid,actLiNo,selGlSaknr,actGeber});
					tobeupdatedar.push({
						actRunid,
						actLineNumber,
						actLineNo,
						actZbcValueDate,
						actWrbtr,
						actWaers,
						actZbcDesc,
						actZbcDesc,
						actZbcCustRef,
						actZbcBankRef,
						actZbcRecType,
						actZbcTranType,
						actZbcRemrk01,
						actZbcDocgrp,
						actSaknr,
						actGeber,
						actBelnr,
						actBuzei,
						actZupdby,
						actReadOnly,
						actAutoDtr,
						actRemrkDisp,
						actItemStatus,
						actMsg,
						actStatus
					});

					docModified = "X";
				} else {

					for (var i = 0; i < tobeupdatedar.length; i++) {
						if (tobeupdatedar[i].actLineNumber === actLineNumber) {
							// tobeupdatedar[i].actSaknr = selGlSaknr;
							tobeupdatedar[i].actSaknr = actSaknr;
							recFound = true;
							docModified = "X";

						}
					}

					if (!recFound) {
						// tobeupdatedar.push({actRunid,actLiNo,selGlSaknr,actGeber});
						//	tobeupdatedar.push({actRunid,actLiNo,actSaknr,actGeber});
						tobeupdatedar.push({
							actRunid,
							actLineNumber,
							actLineNo,
							actZbcValueDate,
							actWrbtr,
							actWaers,
							actZbcDesc,
							actZbcDesc,
							actZbcCustRef,
							actZbcBankRef,
							actZbcRecType,
							actZbcTranType,
							actZbcRemrk01,
							actZbcDocgrp,
							actSaknr,
							actGeber,
							actBelnr,
							actBuzei,
							actZupdby,
							actReadOnly,
							actAutoDtr,
							actRemrkDisp,
							actItemStatus,
							actMsg,
							actStatus
						});

						docModified = "X";

					}
				}

			
				
			// }//If GL Comp


		},

		// FD F4
		onFdF4Help: function (oEvent) {
			debugger;
			this.inFdId = oEvent.getSource().getId();
			this.rowId = oEvent.getSource().oParent.getId();
			this.rowIndex = oEvent.getSource().oParent.getIndex();
			this.oldFdValue = oEvent.getSource().getValue();
		
		//** getting FDF4 values
//conditions

				
					
			
	// conditions
	
	var fdCon= [];
					fdCon.push("EQ");
					fdCon.push("NEQ");
					fdCon.push("Contains");
					
	//conditions

//conditions

	debugger;
	        var aFdFitlers = [];
			aFdFitlers = [
				new Filter('Fikrs', FilterOperator.EQ, "WCMC")
			];
			var oFdF4Model = this.getOwnerComponent().getModel();
			var oJsonFdModel = new sap.ui.model.json.JSONModel();
			var jFDO = {};
			var fdAr = [];
			this.getOwnerComponent().setModel(oJsonFdModel, "resultFdModel");
			oFdF4Model.read("/BCFundSet", {
				
				filters: aFdFitlers,
				
				success: function (data,oRes) {
				debugger;
				
					
					jFDO.con = fdCon; //Conditions

				
					for (var i = 0; i < data.results.length; i++) {
						fdAr.push(data.results[i]);
					}
					jFDO.results = fdAr; 
					oJsonFdModel.setData(jFDO); 
				}
				});

	//**
		
			
			if (!this.fdDialog) {
				this.fdDialog = sap.ui.xmlfragment(this.getView().getId(), "WCMNS.JPMC.view.fragment.fdValueHelp", this);
		// this.fdDialog = sap.ui.xmlfragment(this.getView().getId(), "WCMNS.JPMC.view.fragment.fdDsVHelp", this);
				this.getView().addDependent(this.fdDialog);
			}
			this.fdDialog.open();
		},
		onFdSelF4Help: function (oEvent) {
			debugger;
			docModified = "";
			docSaved = "";
            var selFdGeber = "";
			selFdGeber = oEvent.getSource().getSelectedItem().mAggregations.cells[0].mProperties.text;


			var actRunid = this.getOwnerComponent().getModel("tobeModel").oData.results[this.rowIndex].Runid;
			var actLineNumber = this.getOwnerComponent().getModel("tobeModel").oData.results[this.rowIndex].LineNumber;
			var actLineNo = this.getOwnerComponent().getModel("tobeModel").oData.results[this.rowIndex].LineNo;
			var actZbcValueDate = this.getOwnerComponent().getModel("tobeModel").oData.results[this.rowIndex].ZbcValueDate;
			var actWrbtr = this.getOwnerComponent().getModel("tobeModel").oData.results[this.rowIndex].Wrbtr;
			var actWaers = this.getOwnerComponent().getModel("tobeModel").oData.results[this.rowIndex].Waers;
			var actZbcDesc = this.getOwnerComponent().getModel("tobeModel").oData.results[this.rowIndex].ZbcDesc;
			var actZbcCustRef = this.getOwnerComponent().getModel("tobeModel").oData.results[this.rowIndex].ZbcCustRef;
			var actZbcBankRef = this.getOwnerComponent().getModel("tobeModel").oData.results[this.rowIndex].ZbcBankRef;
			var actZbcRecType = this.getOwnerComponent().getModel("tobeModel").oData.results[this.rowIndex].ZbcRecType;
			var actZbcTranType = this.getOwnerComponent().getModel("tobeModel").oData.results[this.rowIndex].ZbcTranType;
			var actZbcRemrk01 = this.getOwnerComponent().getModel("tobeModel").oData.results[this.rowIndex].ZbcRemrk01;
			var actZbcDocgrp = this.getOwnerComponent().getModel("tobeModel").oData.results[this.rowIndex].ZbcDocgrp;
			var actSaknr = this.getOwnerComponent().getModel("tobeModel").oData.results[this.rowIndex].Saknr;
			var actGeber = this.getOwnerComponent().getModel("tobeModel").oData.results[this.rowIndex].Geber;
			var actBelnr = this.getOwnerComponent().getModel("tobeModel").oData.results[this.rowIndex].Belnr;
			var actBuzei = this.getOwnerComponent().getModel("tobeModel").oData.results[this.rowIndex].Buzei;
			var actZupdby = this.getOwnerComponent().getModel("tobeModel").oData.results[this.rowIndex].Zupdby;
			var actReadOnly = this.getOwnerComponent().getModel("tobeModel").oData.results[this.rowIndex].ReadOnly;
			var actAutoDtr = this.getOwnerComponent().getModel("tobeModel").oData.results[this.rowIndex].AutoDtr;
			var actRemrkDisp = this.getOwnerComponent().getModel("tobeModel").oData.results[this.rowIndex].RemrkDisp;
			var actItemStatus = this.getOwnerComponent().getModel("tobeModel").oData.results[this.rowIndex].ItemStatus;
			var actMsg = this.getOwnerComponent().getModel("tobeModel").oData.results[this.rowIndex].Msg;
			var actStatus = this.getOwnerComponent().getModel("tobeModel").oData.results[this.rowIndex].Status;


			var fdval = this.oldFdVlaue; //PREVIOUS SEELCTION
			// var selFdGeber = oEvent.getParameter("listItem").getBindingContext().getProperty("Fincode"); // CURRENT SELECTION
			// oEvent.getParameters().selectedItems[0].mProperties.title
			var recFdFound = "";
			if (actGeber !== selFdGeber) {
				actGeber = selFdGeber;
				if (tobeupdatedar.length === 0) {


tobeupdatedar.push({
						actRunid,
						actLineNumber,
						actLineNo,
						actZbcValueDate,
						actWrbtr,
						actWaers,
						actZbcDesc,
						actZbcDesc,
						actZbcCustRef,
						actZbcBankRef,
						actZbcRecType,
						actZbcTranType,
						actZbcRemrk01,
						actZbcDocgrp,
						actSaknr,
						actGeber,
						actBelnr,
						actBuzei,
						actZupdby,
						actReadOnly,
						actAutoDtr,
						actRemrkDisp,
						actItemStatus,
						actMsg,
						actStatus
					
					});  //if not equal geber
					docModified = "X";

				} else {

					for (var i = 0; i < tobeupdatedar.length; i++) {
						if (tobeupdatedar[i].actLineNumber === actLineNumber) {
							tobeupdatedar[i].actGeber = selFdGeber;
							recFdFound = true;
							docModified = "X";

						}
					}

					if (!recFdFound) {
						// tobeupdatedar.push({actRunid,actLiNo,actSaknr,selFdGeber});
						
	tobeupdatedar.push({
							actRunid,
							actLineNumber,
							actLineNo,
							actZbcValueDate,
							actWrbtr,
							actWaers,
							actZbcDesc,
							actZbcDesc,
							actZbcCustRef,
							actZbcBankRef,
							actZbcRecType,
							actZbcTranType,
							actZbcRemrk01,
							actZbcDocgrp,
							actSaknr,
							actGeber,
							actBelnr,
							actBuzei,
							actZupdby,
							actReadOnly,
							actAutoDtr,
							actRemrkDisp,
							actItemStatus,
							actMsg,
							actStatus
						
						}); //rec  Not found
						docModified = "X";

					}
				}

			}

			this.getView().byId(this.inFdId).setValue(selFdGeber);
			oEvent.getSource().getParent().close();
			this.fdDialog.close();

		}, //glhelp
		onFdF4HelpClose: function (oEvent) {
			this.fdDialog.close();
		},
		onFdFormSearch: function (oEvent) {
			
            debugger;
            var aFdFilters = [];
			var fdName = this.fdDialog.mAggregations.content[0].mAggregations.items[0].mAggregations.items[1].mProperties.value
			var fdDesc = this.fdDialog.mAggregations.content[0].mAggregations.items[1].mAggregations.items[1].mProperties.value
			var fdFMarea = this.fdDialog.mAggregations.content[0].mAggregations.items[0].mAggregations.items[3].mProperties.value
			var fdFund = this.fdDialog.mAggregations.content[0].mAggregations.items[1].mAggregations.items[3].mProperties.value
		
			
			var oFdFilterF1 = new Filter("Bezeich", sap.ui.model.FilterOperator.Contains, fdName);			
			aFdFilters.push(oFdFilterF1);
			var oFdFilterF2 = new Filter("Beschr", sap.ui.model.FilterOperator.Contains, fdDesc);			
			aFdFilters.push(oFdFilterF2);
			var oFdFilterF3 = new Filter("Fikrs", sap.ui.model.FilterOperator.Contains, fdFMarea);
			aFdFilters.push(oFdFilterF3);
			var oFdFilterF4 = new Filter("Fincode", sap.ui.model.FilterOperator.Contains, fdFund);
			aFdFilters.push(oFdFilterF4);
			var oFdBinding = this.getView().byId("tableFdF").getBinding("items");
			oFdBinding.filter(aFdFilters);

		},
		onFdF4Search: function (oEvent) {

			var sFdValue = oEvent.getParameters("newValue");
			var sFdVal = sFdValue.newValue;
			var oFdSFilter1 = new Filter("Fincode", sap.ui.model.FilterOperator.Contains, sFdVal);
			var aFdSFilters = [];
			aFdSFilters.push(oFdSFilter1);
			var oFdSBinding = this.getView().byId("tableFdF").getBinding("items");
			oFdSBinding.filter(aFdSFilters);

		},
		onFdChange: function (oEvent) {
			debugger;
			var cFdChId = oEvent.getSource().getId();
			var cFdChrowId = oEvent.getSource().oParent.getId();
			var cFdChIndex = oEvent.getSource().oParent.getIndex();
			var cFdChVal = oEvent.getSource().getValue();
			var cfdval = oEvent.getSource().oParent.mAggregations.cells[0].mProperties.text;
			debugger;
			docModified = "";
			docSaved = "";
			
			
			var actRunid = this.getOwnerComponent().getModel("tobeModel").oData.results[cFdChIndex].Runid;
			var actLineNumber = this.getOwnerComponent().getModel("tobeModel").oData.results[cFdChIndex].LineNumber;
			var actLineNo = this.getOwnerComponent().getModel("tobeModel").oData.results[cFdChIndex].LineNo;
			var actZbcValueDate = this.getOwnerComponent().getModel("tobeModel").oData.results[cFdChIndex].ZbcValueDate;
			var actWrbtr = this.getOwnerComponent().getModel("tobeModel").oData.results[cFdChIndex].Wrbtr;
			var actWaers = this.getOwnerComponent().getModel("tobeModel").oData.results[cFdChIndex].Waers;
			var actZbcDesc = this.getOwnerComponent().getModel("tobeModel").oData.results[cFdChIndex].ZbcDesc;
			var actZbcCustRef = this.getOwnerComponent().getModel("tobeModel").oData.results[cFdChIndex].ZbcCustRef;
			var actZbcBankRef = this.getOwnerComponent().getModel("tobeModel").oData.results[cFdChIndex].ZbcBankRef;
			var actZbcRecType = this.getOwnerComponent().getModel("tobeModel").oData.results[cFdChIndex].ZbcRecType;
			var actZbcTranType = this.getOwnerComponent().getModel("tobeModel").oData.results[cFdChIndex].ZbcTranType;
			var actZbcRemrk01 = this.getOwnerComponent().getModel("tobeModel").oData.results[cFdChIndex].ZbcRemrk01;
			var actZbcDocgrp = this.getOwnerComponent().getModel("tobeModel").oData.results[cFdChIndex].ZbcDocgrp;
			var actSaknr = this.getOwnerComponent().getModel("tobeModel").oData.results[cFdChIndex].Saknr;
			var actGeber = this.getOwnerComponent().getModel("tobeModel").oData.results[cFdChIndex].Geber;
			var actBelnr = this.getOwnerComponent().getModel("tobeModel").oData.results[cFdChIndex].Belnr;
			var actBuzei = this.getOwnerComponent().getModel("tobeModel").oData.results[cFdChIndex].Buzei;
			var actZupdby = this.getOwnerComponent().getModel("tobeModel").oData.results[cFdChIndex].Zupdby;
			var actReadOnly = this.getOwnerComponent().getModel("tobeModel").oData.results[cFdChIndex].ReadOnly;
			var actAutoDtr = this.getOwnerComponent().getModel("tobeModel").oData.results[cFdChIndex].AutoDtr;
			var actRemrkDisp = this.getOwnerComponent().getModel("tobeModel").oData.results[cFdChIndex].RemrkDisp;
			var actItemStatus = this.getOwnerComponent().getModel("tobeModel").oData.results[cFdChIndex].ItemStatus;
			var actMsg = this.getOwnerComponent().getModel("tobeModel").oData.results[cFdChIndex].Msg;
			var actStatus = this.getOwnerComponent().getModel("tobeModel").oData.results[cFdChIndex].Status;

			var cFdval = this.oldVlaue; //PREVIOUS SEELCTION
			// var selGlSaknr = oEvent.getParameter("listItem").getBindingContext().getProperty("Saknr"); // CURRENT SELECTION
			var recFound = "";
			// if (actSaknr !== cGlChVal) {
				actGeber = cFdChVal;
				if (tobeupdatedar.length === 0) {
					// tobeupdatedar.push({actRunid,actLiNo,selGlSaknr,actGeber});
					tobeupdatedar.push({
						actRunid,
						actLineNumber,
						actLineNo,
						actZbcValueDate,
						actWrbtr,
						actWaers,
						actZbcDesc,
						actZbcDesc,
						actZbcCustRef,
						actZbcBankRef,
						actZbcRecType,
						actZbcTranType,
						actZbcRemrk01,
						actZbcDocgrp,
						actSaknr,
						actGeber,
						actBelnr,
						actBuzei,
						actZupdby,
						actReadOnly,
						actAutoDtr,
						actRemrkDisp,
						actItemStatus,
						actMsg,
						actStatus
					});

					docModified = "X";
				} else {

					for (var i = 0; i < tobeupdatedar.length; i++) {
						if (tobeupdatedar[i].actLineNumber === actLineNumber) {
							// tobeupdatedar[i].actSaknr = selGlSaknr;
							tobeupdatedar[i].actGeber = actGeber;
							recFound = true;
							docModified = "X";

						}
					}

					if (!recFound) {
						// tobeupdatedar.push({actRunid,actLiNo,selGlSaknr,actGeber});
						//	tobeupdatedar.push({actRunid,actLiNo,actSaknr,actGeber});
						tobeupdatedar.push({
							actRunid,
							actLineNumber,
							actLineNo,
							actZbcValueDate,
							actWrbtr,
							actWaers,
							actZbcDesc,
							actZbcDesc,
							actZbcCustRef,
							actZbcBankRef,
							actZbcRecType,
							actZbcTranType,
							actZbcRemrk01,
							actZbcDocgrp,
							actSaknr,
							actGeber,
							actBelnr,
							actBuzei,
							actZupdby,
							actReadOnly,
							actAutoDtr,
							actRemrkDisp,
							actItemStatus,
							actMsg,
							actStatus
						});

						docModified = "X";

					}
				}

			
			// }//If FD Comp


		},
		
        //Remarks
		onRmF4Help: function (oEvent) {
			debugger;
			var _this = this;
			// oEvent.getSource().getParent().getIndex()
			// this.getView().getId("table1")
			// this.getView().getId("table1")
			// "__xmlview3"
			// this.getView().byId("table1")
			// oEvent.getSource().getModel("tobeModel").getData().results[0].Runid
			// oEvent.getSource().getModel("tobeModel").getData()
			// getSelection()
			// oEvent.getSource().getModel("tobeModel").getData()
			
			
			var rmRowIndex = oEvent.getSource().oParent.getIndex();
			var rmRunid = this.getOwnerComponent().getModel("tobeModel").oData.results[rmRowIndex].Runid; // Act VAL 
			var rmLiNo = this.getOwnerComponent().getModel("tobeModel").oData.results[rmRowIndex].LineNumber; // Act VAL
			var rmSaknr = this.getOwnerComponent().getModel("tobeModel").oData.results[rmRowIndex].Saknr; // Act VAL
			var rmGeber = this.getOwnerComponent().getModel("tobeModel").oData.results[rmRowIndex].Geber;
			var rmZbcRecType = this.getOwnerComponent().getModel("tobeModel").oData.results[rmRowIndex].ZbcRecType;
			var rmZbcDesc = this.getOwnerComponent().getModel("tobeModel").oData.results[rmRowIndex].ZbcDesc;
			var rmZbcCustRef = this.getOwnerComponent().getModel("tobeModel").oData.results[rmRowIndex].ZbcCustRef;
			var rmZbcBankRef = this.getOwnerComponent().getModel("tobeModel").oData.results[rmRowIndex].ZbcBankRef;
			var rmZbcDocgrp = this.getOwnerComponent().getModel("tobeModel").oData.results[rmRowIndex].ZbcDocgrp;
			if(rmZbcRecType === "C"){
			rmZbcRecType = "Credit";
			}
			
			if(rmZbcRecType === "D"){
			rmZbcRecType = "Debit";
			}
			
			var aFitlers = [];
			aFitlers = [
				new Filter('Runid', FilterOperator.EQ, rmRunid),
				new Filter('Linenumber', FilterOperator.EQ, rmLiNo)
			];

			var oRmModel = this.getOwnerComponent().getModel();
			var oJsonRmModel = new sap.ui.model.json.JSONModel();
			var jRmO = {};
			var rmAr = [];
			this.getOwnerComponent().setModel(oJsonRmModel, "resultRmModel");
			oRmModel.read("/RemarksDailogSet", {
				filters: aFitlers,
				success: function (data) {
					debugger;
					
					var rmArH= [];
					rmArH.push(rmZbcRecType);
					rmArH.push(rmZbcDesc);
					rmArH.push(rmZbcCustRef);
					rmArH.push(rmZbcBankRef);
					rmArH.push(rmZbcDocgrp);
					
					jRmO.H = rmArH; //Header Details

					
					// items
					for (var i = 0; i < data.results.length; i++) {
						rmAr.push(data.results[i]);
					}
					jRmO.results = rmAr; 
					oJsonRmModel.setData(jRmO); 

					debugger;
					if (!this.rmDialog) {
						this.rmDialog = sap.ui.xmlfragment(_this.getView().getId(), "WCMNS.JPMC.view.fragment.rmValueHelp", _this);
						_this.getView().addDependent(_this.rmDialog);
					}
					debugger;

this.rmDialog.mAggregations.content[0].mAggregations.items[0].mAggregations.items[1].mProperties.text = rmZbcRecType;
this.rmDialog.mAggregations.content[0].mAggregations.items[1].mAggregations.items[1].mProperties.text = rmZbcDesc;
this.rmDialog.mAggregations.content[0].mAggregations.items[2].mAggregations.items[1].mProperties.text = rmZbcCustRef;
this.rmDialog.mAggregations.content[0].mAggregations.items[3].mAggregations.items[1].mProperties.text = rmZbcBankRef;
this.rmDialog.mAggregations.content[0].mAggregations.items[4].mAggregations.items[1].mProperties.text = rmZbcDocgrp;



// var rmZbcRecType = this.getOwnerComponent().getModel("tobeModel").oData.results[rmRowIndex].ZbcRecType;
// var rmZbcDesc = this.getOwnerComponent().getModel("tobeModel").oData.results[rmRowIndex].ZbcDesc;
// var rmZbcCustRef = this.getOwnerComponent().getModel("tobeModel").oData.results[rmRowIndex].ZbcCustRef;
// var rmZbcBankRef = this.getOwnerComponent().getModel("tobeModel").oData.results[rmRowIndex].ZbcBankRef;
// var rmZbcDocgrp = this.getOwnerComponent().getModel("tobeModel").oData.results[rmRowIndex].ZbcDocgrp;



					this.rmDialog.open();

				}.bind(_this),

				error: function (err) {
					debugger;
					console.log(err);
				}
			});

		}, //rmF4Help
		onRmF4HelpClose: function (oEvent) {
			this.rmDialog.close();
		},
	
	 //Error Log
		onErrors: function (oEvent) {
			debugger;
			// var _this = this;
					if (!this.errDialog) {
						this.errDialog = sap.ui.xmlfragment(this.getView().getId(), "WCMNS.JPMC.view.fragment.errorDetails", this);
						this.getView().addDependent(this.errDialog);
					}
					debugger;
					this.errDialog.open();

		}, //Error Log
		onErrClose: function (oEvent) {
			this.errDialog.close();
		},
	
		
		
		//Other Actions
		onRules: function () {
			this.getOwnerComponent().getRouter().navTo("Rulesroot");
		},
		onBack: function () {
			this.getOwnerComponent().getRouter().navTo("Transactionroot");
		},
		onExScNoac: function (oEvent) {

			var oExport = new Export({

				exportType: new ExportTypeCSV({
					separatorChar: ",",
					charset: "utf-8"
				}),

				models: this.getView().getModel("noacModel"),

				rows: {
					path: "/results"
				},

				columns: [{
					name: "Posting",
					template: {
						content: "{ZbcRecType}"
					}
				}, {
					name: "Transaction Type",
					template: {
						content: "{ZbcDesc}"
					}
				}, {
					name: "Remark",
					template: {
						content: "{ZbcRemrk}"
					}
				}, {
					name: "Amount",
					template: {
						content: "{Wrbtr}"
					}
					// "{Width} x {Depth} x {Height} {DimUnit}"

				}, {
					name: "G/L Accounts",
					template: {
						content: "{Saknr}"
					}
				}, {
					name: "Fund",
					template: {
						//					content : "{Price} {CurrencyCode}"
						content: "{Geber}"
					}
				}]
			});
			oExport.saveFile().catch(function (oError) {
				MessageToast.error("Error in downloading data\n\n" + oError);
			}).then(function () {
				oExport.destroy();
			});
		},
		onExScToBe: function (oEvent) {

			var oExport = new Export({

				exportType: new ExportTypeCSV({
					separatorChar: ",",
					charset: "utf-8"
				}),

				models: this.getView().getModel("tobeModel"),

				rows: {
					path: "/results"
				},

				columns: [{
					name: "Posting",
					template: {
						content: "{ZbcRecType}"
					}
				}, {
					name: "Transaction Type",
					template: {
						content: "{ZbcDesc}"
					}
				}, {
					name: "Remark",
					template: {
						content: "{ZbcRemrk}"
					}
				}, {
					name: "Amount",
					template: {
						content: "{Wrbtr}"
					}
					// "{Width} x {Depth} x {Height} {DimUnit}"

				}, {
					name: "G/L Accounts",
					template: {
						content: "{Saknr}"
					}
				}, {
					name: "Fund",
					template: {
						//					content : "{Price} {CurrencyCode}"
						content: "{Geber}"
					}
				}]
			});

			oExport.saveFile().catch(function (oError) {
				MessageToast.error("Error in downloading data\n\n" + oError);
			}).then(function () {
				oExport.destroy();
			});
		},
		onExScToBeF: function (oEvent) {

			var oExport = new Export({

				exportType: new ExportTypeCSV({
					separatorChar: ",",
					charset: "utf-8"
				}),

				models: this.getView().getModel("resultModel2"),

				rows: {
					path: "/results"
				},


				columns: [{
					name: "Posting",
					template: {
						content: "{ZbcRecType}"
					}
				}, {
					name: "Transaction Type",
					template: {
						content: "{ZbcDesc}"
					}
				}, {
					name: "Remark",
					template: {
						content: "{ZbcRemrk}"
					}
				}, {
					name: "Amount",
					template: {
						content: "{Wrbtr}"
					}
					

				}, {
					name: "G/L Accounts",
					template: {
						content: "{Saknr}"
					}
				}, {
					name: "Fund",
					template: {
						//					content : "{Price} {CurrencyCode}"
						content: "{Geber}"
					}
				}]
			});

			oExport.saveFile().catch(function (oError) {
				MessageToast.error("Error in downloading data\n\n" + oError);
			}).then(function () {
				oExport.destroy();
			});
		},
		onAllValues: function (oEvent) {
			debugger;
			var sValue = "TOBE"
			var oFilter1 = new Filter("RemrkDisp", sap.ui.model.FilterOperator.Contains,sValue );
		
			var aFilters = [];
			aFilters.push(oFilter1);
		
			this.getView().byId("table1").getBinding("rows").filter(aFilters);


		},
		onDefaults: function (oEvent) {
			debugger;
			//Item Staus  = Yellow Color Code 27
			var sValue = "Y" //"27"
			var oFilter1 = new Filter("ItemStatus", sap.ui.model.FilterOperator.Contains,sValue );
		
			var aFilters = [];
			aFilters.push(oFilter1);
		
			this.getView().byId("table1").getBinding("rows").filter(aFilters);

		},
		onDerived: function (oEvent) {
			
			debugger;
			var sValue = "X"
			var sValue2 = ""
			var oFilter1 = new Filter("AutoDtr", sap.ui.model.FilterOperator.Contains,sValue );
			var oFilter2 = new Filter("ItemStatus", sap.ui.model.FilterOperator.EQ,sValue2);
			var aFilters = [];
			aFilters.push(oFilter1);
			aFilters.push(oFilter2);
		
			this.getView().byId("table1").getBinding("rows").filter(aFilters);

			
		},
		onPopUpOk: function () {
			debugger;
			if (docModified == "X" && docSaved == "") {
				debugger;
				var _this = this;
				//	var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				MessageBox.warning(
					"Data has modified,do you want Save it", {
						actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
						//	styleClass: bCompact ? "sapUiSizeCompact" : "",
						onClose: function (sAction) {
							if (sAction == "CANCEL") {
								_this.getOwnerComponent().getRouter().navTo("Transactionroot");
							}
						}
					}
				);
			} else {
				this.getOwnerComponent().getRouter().navTo("Transactionroot");
			}

			// MessageBox.confirm( "Data is not yet Saved "	);

		}, 
		onValueHelpRequested: function() {
			var aCols = this.oColModel.getData().cols;
			this._oBasicSearchField = new SearchField({
				showSearchButton: false
			});

			this._oValueHelpDialog = sap.ui.xmlfragment("WCMNS.JPMC.view.fragment.multiSearchGlValueHelp", this);
			this.getView().addDependent(this._oValueHelpDialog);

			this._oValueHelpDialog.setRangeKeyFields([{
				label: "Product",
				key: "ProductId",
				type: "string",
				typeInstance: new typeString({}, {
					maxLength: 7
				})
			}]);

			this._oValueHelpDialog.getFilterBar().setBasicSearch(this._oBasicSearchField);

			this._oValueHelpDialog.getTableAsync().then(function (oTable) {
				oTable.setModel(this.oProductsModel);
				oTable.setModel(this.oColModel, "columns");

				if (oTable.bindRows) {
					// oTable.bindAggregation("rows", "/ProductCollection");
					oTable.bindAggregation("rows", "{resultFdModel>/results}");
				}

				if (oTable.bindItems) {
					// oTable.bindAggregation("items", "/ProductCollection", function () {
					oTable.bindAggregation("items", "{resultFdModel>/results}", function () {
						return new ColumnListItem({
							cells: aCols.map(function (column) {
								return new Label({ text: "{" + column.template + "}" });
							})
						});
					});
				}

				this._oValueHelpDialog.update();
			}.bind(this));

			this._oValueHelpDialog.setTokens(this._oMultiInput.getTokens());
			this._oValueHelpDialog.open();
		},

	}); //return

}); // define


//junk
// Inside the context of a row (usually after an event on that row):

// oEvent.getSource().getBindingContext().getObject(); //oEvent is the event triggered from that row (press, etc)
// outside the context of a row:

// tbl.getItems()[0].getBindingContext().getObject(); // where tbl.getItems()[0] is a reference to the first row in your table, etc.



//   <script type="text/javascript">
//       window.history.forward();
//       function noBack() { window.history.forward(); }
//     </script>
//   </head>
//   <body onload="noBack();"
//      onpageshow="if (event.persisted) noBack();" onunload="">
// Or we can remove these from the tool bar

// window.open ("URL",
// "mywindow","status=1,toolbar=0");