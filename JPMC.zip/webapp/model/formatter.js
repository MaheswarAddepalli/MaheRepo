sap.ui.define([], function () {
	"use strict";

	return {

		// formatter method contains the formatting logic
		// parameter iInteger gets passed from the view ...
		// ... that uses the formatter
		leadingZeros: function (iInteger) {
			if (iInteger) {
				var sReturn = "";
				sReturn = iInteger.replace(/^0+/, "");
				return sReturn;
			}
		},
		creditdebit: function (iInteger) {
			if (iInteger) {
				var sReturn = "";
				if(iInteger === "C"){
					sReturn = "Credit";
				}
				if(iInteger === "D"){
					sReturn = "Debit";
				}
				return sReturn;
			}
		},
	    dateFormat: function (iInteger) {
			if (iInteger) {
				var sReturn = "";
            var month = iInteger.getMonth() + 1;
            var day = iInteger.getDate();
            var year = iInteger.getFullYear();
            var str = year.toString();
            // sReturn = str + month + day;
             sReturn = month + "/" + day + "/" + str;
            
			return sReturn;
			}
		},
		million: function (iInteger) {
			
			if (iInteger) {
		    var sReturn = "";
            sReturn = new Intl.NumberFormat("en-US", {
                maximumSignificantDigits: 20
            }).format(iInteger);
			return sReturn;
			}
		}
		
    

	};

});